import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { createCW } from './cardapio-web.mjs';
import { createWebhook, openDatabase } from './atendimento.mjs';

// Fictional data and mocked provider. No request reaches the Cardápio Web Sandbox.
export async function verifyFixtures() {
  const db = new DatabaseSync(':memory:');
  const config = {
    environment: 'sandbox', origin: 'https://ret.test', redirect: 'https://ret.test/cardapio-web/callback',
    client: 'fixture', webhookToken: 'fixture-webhook', key: Buffer.alloc(32, 5), units: ['centro', 'bairro'],
    sitesToken: 'test-only-' + 'a'.repeat(43),
  };
  let providerOrder;
  let polling = [];
  let refreshes = 0;
  let shortExpiry = false;
  let requests = 0;
  const challenges = new Map();
  const transport = async (url, options) => {
    requests++;
    const { pathname } = new URL(url);
    const token = options.headers.Authorization;
    if (pathname.endsWith('/oauth/token')) {
      const form = options.body;
      let shop = form.get('code');
      if (form.get('grant_type') === 'refresh_token') {
        shop = form.get('refresh_token').replace('refresh-', '');
        refreshes++;
      } else {
        const verifier = form.get('code_verifier');
        if (createHash('sha256').update(verifier).digest('base64url') !== challenges.get(shop)) {
          return Response.json({ error: 'invalid_grant' }, { status: 400 });
        }
      }
      return Response.json({ access_token: 'access-' + shop, refresh_token: 'refresh-' + shop,
        token_type: 'Bearer', expires_in: shortExpiry && form.get('grant_type') === 'authorization_code'
          ? 30 : 3600, scope: 'store orders catalog' });
    }
    if (pathname.endsWith('/merchant')) {
      const id = token.replace('Bearer access-', '');
      return Response.json({ id, name: 'Loja fictícia ' + id });
    }
    if (pathname.endsWith('/oauth/revoke')) return new Response(null, { status: 204 });
    if (pathname.endsWith('/orders')) return Response.json(polling);
    if (pathname.endsWith('/orders/9001')) return Response.json(providerOrder);
    if (pathname.endsWith('/orders/history')) return Response.json({
      orders: [{ id: '9004', status: 'closed', updated_at: providerOrder.updated_at }],
      pagination: { current_page: 1, total_pages: 1, total_orders: 1 },
    });
    if (pathname.endsWith('/orders/summary/grouped')) {
      const params = new URL(url).searchParams;
      assert.equal(params.get('group_by'), 'day');
      assert.equal(params.getAll('filters[status_in]').join(','), 'closed,canceled');
      assert.match(params.get('start_date'), /T00:00:00-03:00$/);
      return Response.json({ total_order_count: 2 });
    }
    if (pathname.endsWith('/catalog')) return Response.json({ categories: [{ id: 1, name: 'Salgados' }] });
    throw new Error('Rota inesperada no teste');
  };
  const cw = createCW(db, config, transport);
  try {
    const grant = cw.grant();
    const signedIn = cw.useGrant(grant);
    assert.ok(signedIn);
    assert.equal(cw.useGrant(grant), null);
    const authorize = async (unit, shop, session = 'operator') => {
      const { searchParams } = new URL(cw.start(session, unit));
      challenges.set(shop, searchParams.get('code_challenge'));
      assert.equal(searchParams.get('redirect_uri'), config.redirect);
      assert.equal(searchParams.get('scope'), null);
      const state = searchParams.get('state');
      await assert.rejects(cw.callback('other', state, shop));
      const pending = await cw.callback(session, state, shop);
      await assert.rejects(cw.callback(session, state, shop));
      return pending;
    };
    const expired = new URL(cw.start('operator', 'centro')).searchParams.get('state');
    db.exec('UPDATE cw_attempts SET expires=0');
    await assert.rejects(cw.callback('operator', expired, '1'));
    const wrong = new URL(cw.start('operator', 'centro')).searchParams.get('state');
    await assert.rejects(cw.callback('operator', wrong, '7'), /HTTP 400/);
    const center = await authorize('centro', '1');
    assert.equal(db.prepare('SELECT count(*) AS n FROM cw_installations').get().n, 0);
    assert.throws(() => cw.confirm('other', center.id));
    cw.confirm('operator', center.id);
    const invalidMapping = await authorize('bairro', '1');
    assert.throws(() => cw.confirm('operator', invalidMapping.id), /outra unidade/);
    cw.confirm('operator', (await authorize('bairro', '2')).id);
    assert.equal(db.prepare('SELECT count(*) AS n FROM cw_installations').get().n, 2);
    assert.ok(!db.prepare('SELECT credentials FROM cw_installations').get().credentials.includes('refresh-1'));
    const event = { event_type: 'ORDER_CREATED', event_id: 'evt-1', merchant_id: '1', order_id: '9001' };
    const before = requests;
    assert.equal(cw.acceptEvent('invalid', event), 403);
    assert.equal(cw.acceptEvent(config.webhookToken, { ...event, merchant_id: '3' }), 404);
    assert.equal(requests, before);
    assert.equal(cw.acceptEvent(config.webhookToken, event), 200);
    assert.equal(cw.acceptEvent(config.webhookToken, event), 200);
    assert.equal(db.prepare('SELECT count(*) AS n FROM cw_inbox').get().n, 1);
    providerOrder = { id: '9001', merchant_id: '1', display_id: 21, status: 'ready',
      updated_at: '2026-11-18T12:30:00-03:00', total: 9.5, customer: { name: 'Fictício' },
      schedule: { time: '2026-11-18T13:00:00-03:00' },
      items: [{ name: 'Combo', items: [{ name: 'Coxinha', options: [{ name: 'Molho', unit_price: 1 }] }] }],
      payments: [{ total: 9.5, payment_fee: 0 }], discounts: [{ total: 1 }] };
    const worker = createCW(db, config, transport);
    await worker.workOnce();
    assert.equal(db.prepare('SELECT status FROM cw_inbox').get().status, 'done');
    polling = [{ ...providerOrder, status: 'confirmed', updated_at: '2026-11-18T12:00:00-03:00' },
      { ...providerOrder, id: '9002', order_type: 'closed_table', status: 'closed' }];
    await worker.poll('centro');
    assert.equal(db.prepare('SELECT count(*) AS n FROM cw_orders').get().n, 2);
    const stored = JSON.parse(db.prepare("SELECT payload FROM cw_orders WHERE id='9001'").get().payload);
    assert.equal(stored.status, 'ready');
    assert.equal(stored.customer, undefined);
    assert.deepEqual(stored.items, providerOrder.items);
    assert.deepEqual(stored.schedule, providerOrder.schedule);
    polling = [{ ...providerOrder, merchant_id: '2' }];
    await worker.poll('bairro');
    assert.equal(db.prepare("SELECT count(*) AS n FROM cw_orders WHERE id='9001'").get().n, 2);
    const old = db.prepare("SELECT watermark FROM cw_installations WHERE unit='centro'").get().watermark;
    polling = [{ ...providerOrder, id: '9003' }, { ...providerOrder, merchant_id: '2' }];
    await assert.rejects(worker.poll('centro'), /inconsistente/);
    assert.equal(db.prepare("SELECT watermark FROM cw_installations WHERE unit='centro'").get().watermark, old);
    assert.equal(db.prepare("SELECT count(*) AS n FROM cw_orders WHERE id='9003'").get().n, 0);
    polling = [];
    const today = new Date().toISOString().slice(0, 10);
    const dates = { start_date: today, end_date: today };
    assert.equal((await worker.history('centro', new URLSearchParams(dates))).total_orders, 1);
    assert.ok(db.prepare("SELECT 1 FROM cw_inbox WHERE order_id='9004'").get());
    await assert.rejects(worker.indicators('centro', new URLSearchParams({
      ...dates, date_field: 'scheduled_date', group_by: 'hour',
    })), /Agrupamento inválido/);
    const report = new URLSearchParams({ ...dates, group_by: 'day' });
    report.append('status', 'closed');
    report.append('status', 'canceled');
    assert.equal((await worker.indicators('centro', report)).total_order_count, 2);
    shortExpiry = true;
    cw.confirm('operator', (await authorize('centro', '1')).id);
    const operations = await Promise.allSettled([worker.refreshCatalog('centro'), worker.refreshCatalog('centro')]);
    assert.deepEqual(operations.map(result => result.status), ['fulfilled', 'rejected']);
    await worker.refreshCatalog('centro');
    assert.equal(refreshes, 1);
    await worker.disconnect('centro');
    assert.equal(db.prepare("SELECT status FROM cw_installations WHERE unit='centro'").get().status, 'disconnected');
    assert.equal(cw.acceptEvent(config.webhookToken, event), 404);
  } finally { db.close(); }

  const serverDb = openDatabase(':memory:');
  const cwHttp = createCW(serverDb, config, transport);
  const server = createWebhook({ db: serverDb, channels: {}, cw: cwHttp, verifyToken: 'meta-check', secret: 'fake' });
  await new Promise((resolve, reject) => server.once('error', reject).listen(0, '127.0.0.1', resolve));
  const url = 'http://127.0.0.1:' + server.address().port;
  try {
    assert.equal((await fetch(url + '/webhooks/meta?hub.mode=subscribe&hub.verify_token=meta-check&hub.challenge=123')).status, 200);
    assert.equal(await (await fetch(url + '/healthz')).text(), 'ok');
    const overview = url + '/cardapio-web/api/overview?unit=centro';
    assert.equal((await fetch(overview)).status, 401);
    const serviceHeaders = { Authorization: 'Bearer ' + config.sitesToken };
    assert.equal((await (await fetch(overview, { headers: serviceHeaders })).json()).connected, false);
    serverDb.prepare(`INSERT INTO cw_installations(unit,environment,merchant,name,status,catalog)
      VALUES ('centro','sandbox','1','Teste','active',?)`).run(JSON.stringify({
      categories: [{ id: 1, name: 'Salgados', items: [{ id: 2, name: 'Coxinha',
        price: 3, status: 'ACTIVE', cost_price: 1, stock: 25 }] }],
    }));
    const siteData = await (await fetch(overview, { headers: serviceHeaders })).json();
    assert.equal(siteData.connected, true);
    assert.equal(siteData.categories[0].items[0].price, 3);
    assert.equal(siteData.categories[0].items[0].cost_price, undefined);
    assert.equal(siteData.categories[0].items[0].stock, undefined);
    assert.equal((await fetch(url + '/cardapio-web/api/overview?unit=other', { headers: serviceHeaders })).status, 404);
    assert.equal((await fetch(url + '/cardapio-web/orders')).status, 401);
    const login = await fetch(url + '/cardapio-web/login', {
      method: 'POST', headers: { Origin: config.origin }, redirect: 'manual',
      body: new URLSearchParams({ code: cwHttp.grant() }),
    });
    assert.equal(login.status, 303);
    const cookie = login.headers.get('set-cookie');
    assert.match(cookie, /Secure; HttpOnly; SameSite=Lax/);
    const orders = await fetch(url + '/cardapio-web/orders', { headers: { Cookie: cookie.split(';')[0] } });
    assert.equal(orders.status, 200);
    assert.match(await orders.text(), /Nenhum pedido encontrado/);
    const badOrigin = await fetch(url + '/cardapio-web/connect', { method: 'POST',
      body: new URLSearchParams({ unit: 'centro' }) });
    assert.equal(badOrigin.status, 403);
    serverDb.exec('DROP TABLE cw_installations');
    const failure = await fetch(url + '/webhooks/cardapio-web', {
      method: 'POST', headers: { 'X-Webhook-Token': config.webhookToken },
      body: JSON.stringify({ event_type: 'ORDER_CREATED', event_id: 'ficticio', merchant_id: 1, order_id: 9001 }),
    });
    assert.equal(failure.status, 503);
  } finally {
    await new Promise(resolve => server.close(resolve));
    serverDb.close();
  }
}

if (globalThis.process) await verifyFixtures();
