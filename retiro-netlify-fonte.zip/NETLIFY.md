# Retiro Atendimento na Netlify

O projeto de teste mantém o HTML publicado e adiciona funções HTTPS e uma migração PostgreSQL. O servidor Node.js com SQLite continua disponível para execução local.

## Publicação

Vincule o código-fonte a um repositório privado e conecte o repositório ao projeto **retiroatendimento** da Netlify. O `netlify.toml` publica `central-netlify/` e empacota `netlify/functions/`. Use Netlify Database no projeto. A Netlify aplica a migração em `netlify/database/migrations/` na publicação. O ZIP que contém só o HTML não é a publicação do backend. [Publicação da Netlify](https://docs.netlify.com/deploy/create-deploys/) · [Migrações do banco](https://docs.netlify.com/build/data-and-storage/netlify-database/migrations/)

Antes de publicar, instale as dependências com `npm install`, versione o lockfile resolvido e execute `npm test`. Se o deploy inicial for feito sem credenciais da Cardápio Web, confira `GET /healthz` e veja que a página de consulta responde que o Sandbox ainda precisa de configuração. O cron sai antes de consultar o banco enquanto faltam variáveis.

## Endereços para o cadastro

- Instalação e acesso: `https://retiroatendimento.netlify.app/cardapio-web`
- Retorno OAuth: `https://retiroatendimento.netlify.app/cardapio-web/callback`
- Webhook: `https://retiroatendimento.netlify.app/webhooks/cardapio-web`

Confirme essas rotas no deploy antes de enviá-las ao suporte. O callback deve coincidir exatamente com o cadastrado.

## Configuração privada

Na Netlify, configure as variáveis com escopo de execução das funções:

- `CW_ENVIRONMENT=sandbox`
- `CW_CLIENT_ID` e `CW_WEBHOOK_TOKEN`, fornecidos pelo suporte para o Sandbox
- `CW_REDIRECT_URI`, igual à URL cadastrada
- `CW_ENCRYPTION_KEY`, 32 bytes aleatórios em hexadecimal, com cópia segura antes da autorização
- `CW_OPERATOR_CODE_SHA256`, hash SHA-256 em hexadecimal de um código aleatório de 32 bytes em base64url

Gere o código de entrada em um terminal privado. Guarde o código com o operador e salve somente o hash nas variáveis da Netlify. O código é de uso único. Ele abre uma sessão de oito horas para um operador. Para abrir outra sessão, gere outro código e atualize o hash. A alteração invalida a sessão anterior.

```powershell
node -e "const {randomBytes,createHash}=require('node:crypto');const code=randomBytes(32).toString('base64url');console.log('Código:',code);console.log('Hash:',createHash('sha256').update(code).digest('hex'))"
```

Entre em `/cardapio-web`, inicie a autorização no perfil Proprietário da loja de testes e confira o nome e o ID antes de associar. O painel apresenta catálogo resumido e pedidos recentes. O webhook guarda eventos autenticados antes de responder. A função agendada tenta processá-los e reconcilia pedidos a cada cinco minutos após a ativação. O horário do teste e o tamanho do lote foram escolhidos para o Sandbox. O plano gratuito tem limite de créditos. [Consumo de créditos](https://docs.netlify.com/manage/accounts-and-billing/billing/billing-for-credit-based-plans/how-credits-work/)

A versão Netlify atende uma loja Sandbox e preserva apenas o resumo dos pedidos e do catálogo. O histórico, os indicadores e os detalhes mais amplos continuam na edição Node.js/SQLite. O Direct, os comentários, a publicação de mensagens e as operações de escrita não fazem parte deste deploy de teste.
