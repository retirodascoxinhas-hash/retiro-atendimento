import { getDatabase } from '@netlify/database';
import { sandbox, sandboxConfig } from '../backend/cardapio.mjs';

export const config = { schedule: '*/5 * * * *' };

export default async function handler() {
  try {
    const settings = sandboxConfig(process.env);
    if (settings) await sandbox(getDatabase().pool, settings).runScheduled();
    return new Response(null, { status: 204 });
  } catch {
    console.error('Falha na reconciliação Sandbox do Cardápio Web.');
    return new Response(null, { status: 503 });
  }
}
