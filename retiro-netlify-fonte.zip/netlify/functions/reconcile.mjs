import { getDatabase } from '@netlify/database';
import { sandbox, sandboxConfig } from '../backend/cardapio.mjs';
import { instagramSettings } from '../backend/instagram.mjs';

export const config = { schedule: '*/5 * * * *' };

export default async function handler() {
  try {
    if (instagramSettings(process.env)) {
      await getDatabase().pool.query("DELETE FROM instagram_inbox WHERE received_at < now() - interval '7 days'");
    }
  } catch {
    console.error('Falha na retenção da caixa do Instagram.');
  }
  try {
    const settings = sandboxConfig(process.env);
    if (settings) await sandbox(getDatabase().pool, settings).runScheduled();
    return new Response(null, { status: 204 });
  } catch {
    console.error('Falha na reconciliação Sandbox do Cardápio Web.');
    return new Response(null, { status: 503 });
  }
}
