import { getDatabase } from '@netlify/database';
import { instagramSettings, receiveInstagram } from '../backend/instagram.mjs';

export const config = { path: '/webhooks/meta' };

export default async function handler(req) {
  try {
    return await receiveInstagram(req, instagramSettings(process.env), (sql, args) => getDatabase().pool.query(sql, args));
  } catch {
    return new Response('Instagram indisponível.', { status: 503 });
  }
}
