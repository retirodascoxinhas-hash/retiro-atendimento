import { getDatabase } from '@netlify/database';
import { sandbox, sandboxConfig } from '../backend/cardapio.mjs';

export const config = { path: ['/healthz', '/cardapio-web', '/cardapio-web/*', '/webhooks/cardapio-web'] };

export default async function handler(req) {
  if (new URL(req.url).pathname === '/healthz') {
    return new Response(req.method === 'GET' ? 'ok' : '', { status: req.method === 'GET' ? 200 : 405 });
  }
  try {
    const settings = sandboxConfig(process.env);
    if (!settings) return new Response('Sandbox ainda não configurado.', { status: 503 });
    return await sandbox(getDatabase().pool, settings).handle(req);
  } catch {
    return new Response('Sandbox indisponível.', { status: 503 });
  }
}
