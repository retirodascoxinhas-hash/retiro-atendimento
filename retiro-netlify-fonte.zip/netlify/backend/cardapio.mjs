import { createCipheriv, createDecipheriv, createHash, randomBytes, timingSafeEqual } from 'node:crypto';

const ROOT = '/cardapio-web';
const API = 'https://integracao.sandbox.cardapioweb.com/api/partner';
const random = () => randomBytes(32).toString('base64url');
const hash = value => createHash('sha256').update(value).digest('base64url');
const equal = (value, secret) => typeof value === 'string' && value.length <= 2048 &&
  timingSafeEqual(Buffer.from(hash(value)), Buffer.from(hash(secret)));
const identifier = value => (typeof value === 'string' || Number.isSafeInteger(value)) &&
  /^[\w-]{1,128}$/.test(String(value)) ? String(value) : null;
const html = value => String(value ?? '').replace(/[&<>"']/g, ch =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);
const page = (title, content) => `<!doctype html><html lang="pt-BR"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>${html(title)}</title>
<style>body{margin:2rem auto;padding:0 1rem;max-width:54rem;font:1rem system-ui;color:#222c25;background:#faf8f3}
button,input{font:inherit;padding:.6rem;border:1px solid #234a37;border-radius:.4rem;margin:.3rem}
button{background:#234a37;color:white}a{color:#234a37}section{padding:1rem;background:white;margin:1rem 0}
:focus-visible{outline:3px solid #a6531e}</style>
<a href="/">Retiro Atendimento</a><h1>${html(title)}</h1>${content}</html>`;
const button = (route, title, input = '') =>
  `<form action="${ROOT}/${route}" method="post">${input}<button>${title}</button></form>`;
const response = (status, body = '', headers = {}) => new Response(body, {
  status, headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store',
    'Referrer-Policy': 'no-referrer', 'X-Content-Type-Options': 'nosniff',
    'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'",
    ...headers },
});

export function sandboxConfig(env) {
  if (env.CW_ENVIRONMENT !== 'sandbox' || !env.CW_CLIENT_ID || !env.CW_WEBHOOK_TOKEN ||
      !/^[a-f\d]{64}$/i.test(env.CW_ENCRYPTION_KEY ?? '') ||
      !/^[a-f\d]{64}$/i.test(env.CW_OPERATOR_CODE_SHA256 ?? '')) return null;
  const redirect = new URL(env.CW_REDIRECT_URI);
  if (redirect.protocol !== 'https:' || redirect.pathname !== ROOT + '/callback' ||
      redirect.username || redirect.password || redirect.search || redirect.hash) throw new Error('Callback inválido');
  return { redirect: env.CW_REDIRECT_URI, origin: redirect.origin, client: env.CW_CLIENT_ID,
    webhook: env.CW_WEBHOOK_TOKEN, operatorHash: env.CW_OPERATOR_CODE_SHA256.toLowerCase(),
    key: Buffer.from(env.CW_ENCRYPTION_KEY, 'hex') };
}

class ApiError extends Error {
  constructor(status, code, retry) {
    super('Falha no Cardápio Web');
    Object.assign(this, { status, code, retry });
  }
}

export function sandbox(pool, config, transport = fetch) {
  const query = (sql, values) => pool.query(sql, values);
  async function tx(work) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const result = await work(client);
      await client.query('COMMIT');
      return result;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally { client.release(); }
  }

  function seal(value, purpose) {
    const iv = randomBytes(12);
    const cipher = createCipheriv('aes-256-gcm', config.key, iv);
    cipher.setAAD(Buffer.from(purpose));
    const bytes = Buffer.concat([cipher.update(JSON.stringify(value)), cipher.final()]);
    return Buffer.concat([iv, cipher.getAuthTag(), bytes]).toString('base64url');
  }
  function unseal(value, purpose) {
    const bytes = Buffer.from(value, 'base64url');
    const decipher = createDecipheriv('aes-256-gcm', config.key, bytes.subarray(0, 12));
    decipher.setAAD(Buffer.from(purpose));
    decipher.setAuthTag(bytes.subarray(12, 28));
    return JSON.parse(Buffer.concat([decipher.update(bytes.subarray(28)), decipher.final()]));
  }
  async function api(path, { access, fields } = {}) {
    const result = await transport(API + path, {
      method: fields ? 'POST' : 'GET', headers: access ? { Authorization: 'Bearer ' + access } : {},
      body: fields && new URLSearchParams({ ...fields, client_id: config.client }),
      redirect: 'error', signal: AbortSignal.timeout(3500),
    });
    if (!result.ok) {
      const error = await result.json().catch(() => ({}));
      const after = result.headers.get('Retry-After');
      const retry = Math.max(Date.now() + 60_000, /^\d+$/.test(after ?? '')
        ? Date.now() + Number(after) * 1000 : Date.parse(after) || 0);
      throw new ApiError(result.status, error?.error, retry);
    }
    return result.json();
  }
  async function token(fields, previous) {
    const data = await api('/oauth/token', { fields });
    const expiry = Number(data?.expires_in);
    const refresh = data?.refresh_token ?? previous?.refresh;
    if (!data?.access_token || typeof data.access_token !== 'string' || typeof refresh !== 'string' ||
        !refresh || String(data.token_type).toLowerCase() !== 'bearer' || !Number.isFinite(expiry) || expiry <= 0) {
      throw new Error('Credencial inválida');
    }
    return { access: data.access_token, refresh, expiry: Date.now() + expiry * 1000 };
  }
  async function access() {
    return tx(async client => {
      const { rows: [row] } = await client.query('SELECT * FROM sandbox_store WHERE singleton FOR UPDATE');
      if (!row?.enabled || new Date(row.blocked_until).getTime() > Date.now()) return null;
      const old = unseal(row.credentials, 'token:' + row.merchant);
      if (old.expiry > Date.now() + 60_000) return { row, access: old.access };
      try {
        const next = await token({ grant_type: 'refresh_token', refresh_token: old.refresh }, old);
        row.credentials = seal(next, 'token:' + row.merchant);
        await client.query('UPDATE sandbox_store SET credentials=$1 WHERE singleton',
          [row.credentials]);
        return { row, access: next.access };
      } catch (error) {
        if (error.code === 'invalid_grant' || [401, 403].includes(error.status)) {
          await client.query('UPDATE sandbox_store SET enabled=false WHERE singleton');
          return null;
        }
        if (error.status === 429) {
          await client.query('UPDATE sandbox_store SET blocked_until=$1 WHERE singleton', [new Date(error.retry)]);
          return null;
        }
        throw error;
      }
    });
  }
  async function read(path, connection) {
    try { return await api('/v1' + path, { access: connection.access }); }
    catch (error) {
      if ([401, 403, 429].includes(error.status)) {
        await query('UPDATE sandbox_store SET enabled=$1,blocked_until=$2 WHERE merchant=$3 AND credentials=$4',
          [error.status === 429, error.status === 429 ? new Date(error.retry) : null,
            connection.row.merchant, connection.row.credentials]);
      }
      throw error;
    }
  }
  function orderData(order, merchant, expected) {
    const id = identifier(order?.id);
    const updated = Date.parse(order?.updated_at);
    if (!id || !Number.isFinite(updated) || typeof order.status !== 'string' ||
        (order.merchant_id != null && identifier(order.merchant_id) !== merchant) || (expected && expected !== id)) {
      throw new Error('Pedido inconsistente');
    }
    return [merchant, id, new Date(updated), typeof order.display_id === 'number' || typeof order.display_id === 'string'
      ? String(order.display_id) : null, order.status,
      /^\d{1,12}(\.\d{1,4})?$/.test(String(order.total ?? '')) ? String(order.total) : null];
  }
  async function persist(client, order, merchant, expected) {
    await client.query(`INSERT INTO sandbox_order VALUES ($1,$2,$3,$4,$5,$6)
      ON CONFLICT (merchant,remote_id) DO UPDATE SET updated_at=EXCLUDED.updated_at,status=EXCLUDED.status,
      display_id=COALESCE(EXCLUDED.display_id,sandbox_order.display_id),
      total=COALESCE(EXCLUDED.total,sandbox_order.total)
      WHERE sandbox_order.updated_at <= EXCLUDED.updated_at`, orderData(order, merchant, expected));
  }
  async function syncOrders() {
    const connection = await access();
    if (!connection) return false;
    const now = Date.now();
    const since = Math.max(now - 23.9 * 3_600_000,
      connection.row.reconciled_at ? new Date(connection.row.reconciled_at).getTime() - 120_000 : now - 8 * 3_600_000);
    const orders = await read('/orders?' + new URLSearchParams({ updated_since: new Date(since).toISOString() }), connection);
    if (!Array.isArray(orders)) throw new Error('Lista inválida');
    await tx(async client => {
      for (const order of orders) await persist(client, order, connection.row.merchant);
      await client.query('UPDATE sandbox_store SET reconciled_at=GREATEST(reconciled_at,$1) WHERE merchant=$2',
        [new Date(now), connection.row.merchant]);
    });
    return true;
  }
  async function runScheduled() {
    const connection = await access();
    if (!connection) return;
    const { rows } = await query(`WITH claim AS (
      SELECT event_id FROM sandbox_event WHERE merchant=$1 AND NOT done AND retry_at<=now() AND attempts<8
      ORDER BY received_at LIMIT 2 FOR UPDATE SKIP LOCKED
    ) UPDATE sandbox_event AS event SET retry_at=now()+interval '5 minutes', attempts=attempts+1
      FROM claim WHERE event.event_id=claim.event_id RETURNING event.*`, [connection.row.merchant]);
    for (const event of rows) {
      try {
        const order = await read('/orders/' + encodeURIComponent(event.order_id), connection);
        await tx(async client => {
          await persist(client, order, event.merchant, event.order_id);
          await client.query('UPDATE sandbox_event SET done=true WHERE event_id=$1', [event.event_id]);
        });
      } catch (error) {
        if ([401, 403, 429].includes(error.status)) return;
      }
    }
    await syncOrders();
  }

  async function dashboard(session) {
    const { rows: [pending] } = await query(`SELECT state_hash,merchant,store_name FROM sandbox_attempt
      WHERE session_hash=$1 AND merchant IS NOT NULL AND expires_at>now()
      ORDER BY expires_at DESC LIMIT 1`, [session]);
    const { rows: [store] } = await query('SELECT merchant,store_name,enabled,catalog,reconciled_at FROM sandbox_store WHERE singleton');
    const { rows: orders } = store?.enabled ? await query(`SELECT remote_id,display_id,status,total,updated_at
      FROM sandbox_order WHERE merchant=$1 ORDER BY updated_at DESC LIMIT 30`, [store.merchant]) : { rows: [] };
    return page('Cardápio Web · Sandbox',
      '<p>' + (store ? html(store.store_name) + ' · ' + (store.enabled ? 'Conectada' : 'Precisa reconectar')
        : 'Aguardando autorização do proprietário.') + '</p>' +
      (pending ? '<section><p>Confirme a loja ' + html(pending.store_name) + ' (' + html(pending.merchant) + ').</p>' +
        button('confirm', 'Associar loja', '<input type="hidden" name="id" value="' + html(pending.state_hash) + '">') + '</section>' : '') +
      button('connect', store?.enabled ? 'Reautorizar loja' : 'Autorizar loja') +
      (store?.enabled ? button('catalog', 'Consultar cardápio') + button('orders', 'Atualizar pedidos') +
        '<h2>Cardápio</h2>' + (store.catalog?.map(category => '<section><strong>' + html(category.name) +
          '</strong><ul>' + category.items.map(item => '<li>' + html(item.name) + ' · R$ ' +
          html(item.price) + '</li>').join('') + '</ul></section>').join('') || '<p>Sem catálogo consultado.</p>') +
        '<h2>Pedidos recentes</h2><p>Última consulta: ' + html(store.reconciled_at ? new Date(store.reconciled_at).toISOString() : 'pendente') +
        '</p>' + (orders.length ? '<ul>' + orders.map(order => '<li>' + html(order.display_id ?? order.remote_id) +
          ' · ' + html(order.status) + (order.total == null ? '' : ' · R$ ' + html(order.total)) + '</li>').join('') +
          '</ul>' : '<p>Sem pedidos sincronizados.</p>') : ''));
  }
  async function handle(req) {
    const url = new URL(req.url);
    try {
      if (url.pathname === '/webhooks/cardapio-web') {
        if (req.method !== 'POST') return response(405);
        if (!equal(req.headers.get('X-Webhook-Token'), config.webhook)) return response(403);
        const raw = await req.text();
        if (Buffer.byteLength(raw) > 65_536) return response(413);
        let event;
        try { event = JSON.parse(raw); } catch { return response(400); }
        const [id, merchant, order] = [event?.event_id, event?.merchant_id, event?.order_id].map(identifier);
        if (!id || !merchant || !order || !['ORDER_CREATED', 'ORDER_STATUS_UPDATED'].includes(event.event_type)) {
          return response(400);
        }
        const result = await query(`WITH store AS (SELECT merchant FROM sandbox_store WHERE enabled AND merchant=$2),
          accepted AS (INSERT INTO sandbox_event (event_id,merchant,order_id) SELECT $1,merchant,$3 FROM store
            ON CONFLICT (event_id) DO NOTHING) SELECT merchant FROM store`, [id, merchant, order]);
        return response(result.rows.length ? 200 : 404);
      }
      if (url.origin !== config.origin) return response(404);
      const action = url.pathname.slice(ROOT.length + 1);
      const sessionCookie = req.headers.get('Cookie')?.match(/(?:^|;\s*)__Host-retcardapio=([\w-]{43})(?:;|$)/)?.[1];
      if (req.method === 'POST' && (req.headers.get('Origin') !== config.origin ||
          !req.headers.get('Content-Type')?.startsWith('application/x-www-form-urlencoded'))) return response(403);
      if (req.method === 'POST' && action === 'login') {
        const form = new URLSearchParams(await req.text());
        const code = form.get('code') ?? '';
        const codeHash = createHash('sha256').update(code).digest('hex');
        if (!/^[\w-]{43}$/.test(code) || !equal(codeHash, config.operatorHash)) return response(403);
        const cookie = random();
        const inserted = await query(`INSERT INTO sandbox_operator VALUES ($1,$2,now()+interval '8 hours')
          ON CONFLICT (key_hash) DO NOTHING RETURNING key_hash`, [codeHash, hash(cookie)]);
        if (!inserted.rows.length) return response(403, page('Código já usado', '<p>Gere um novo código de entrada.</p>'));
        return response(303, '', { Location: ROOT, 'Set-Cookie': '__Host-retcardapio=' + cookie +
          '; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=28800' });
      }
      const session = sessionCookie && hash(sessionCookie);
      const operator = session && (await query(`SELECT 1 FROM sandbox_operator
        WHERE session_hash=$1 AND key_hash=$2 AND expires_at>now()`, [session, config.operatorHash])).rows.length;
      if (!operator) return req.method === 'GET' && action === '' ? response(401, page('Acesso do operador',
        button('login', 'Entrar', '<label>Código de uso único <input type="password" required name="code" autocomplete="off"></label>'))) : response(401);
      if (req.method === 'GET' && action === '') return response(200, await dashboard(session));
      if (req.method === 'POST' && action === 'connect') {
        const state = random();
        const verifier = randomBytes(48).toString('base64url');
        const stateHash = hash(state);
        await query('DELETE FROM sandbox_attempt WHERE expires_at<=now() OR session_hash=$1', [session]);
        await query("INSERT INTO sandbox_attempt (state_hash,session_hash,verifier,expires_at) VALUES ($1,$2,$3,now()+interval '10 minutes')",
          [stateHash, session, seal(verifier, 'pkce:' + stateHash)]);
        const target = 'https://portal.sandbox.cardapioweb.com/cw-apps?' + new URLSearchParams({
          client_id: config.client, redirect_uri: config.redirect, state,
          code_challenge: hash(verifier), code_challenge_method: 'S256',
        });
        return response(200, page('Autorizar loja de teste', '<p>Entre como Proprietário da loja de teste.</p><a href="' +
          html(target) + '">Continuar para o Cardápio Web</a>'));
      }
      if (req.method === 'GET' && action === 'callback') {
        const stateHash = hash(url.searchParams.get('state') ?? '');
        const code = url.searchParams.get('code');
        if (!code || url.searchParams.has('error')) return response(400, page('Autorização não concluída',
          '<p>Confira se você tem o perfil Proprietário e inicie novamente.</p>'));
        const { rows: [attempt] } = await query(`DELETE FROM sandbox_attempt WHERE state_hash=$1 AND session_hash=$2
          AND merchant IS NULL AND expires_at>now() RETURNING verifier`, [stateHash, session]);
        if (!attempt) return response(400, page('Autorização expirada', '<a href="' + ROOT + '">Recomeçar</a>'));
        const credentials = await token({ grant_type: 'authorization_code', redirect_uri: config.redirect, code,
          code_verifier: unseal(attempt.verifier, 'pkce:' + stateHash) });
        const store = await api('/v1/merchant', credentials);
        const merchant = identifier(store?.id);
        if (!merchant || typeof store?.name !== 'string' || !store.name.trim()) throw new Error('Loja inválida');
        await query(`INSERT INTO sandbox_attempt VALUES ($1,$2,'',now()+interval '10 minutes',$3,$4,$5)`,
          [hash(random()), session, merchant, store.name, seal(credentials, 'token:' + merchant)]);
        return response(303, '', { Location: ROOT });
      }
      if (req.method === 'POST' && action === 'confirm') {
        const fields = new URLSearchParams(await req.text());
        const saved = await query(`WITH candidate AS (
          DELETE FROM sandbox_attempt WHERE state_hash=$1 AND session_hash=$2 AND merchant IS NOT NULL
            AND expires_at>now() RETURNING merchant,store_name,credentials
        ) INSERT INTO sandbox_store (merchant,store_name,credentials) SELECT * FROM candidate
          ON CONFLICT (singleton) DO UPDATE SET store_name=EXCLUDED.store_name,credentials=EXCLUDED.credentials,
            enabled=true,blocked_until=NULL WHERE sandbox_store.merchant=EXCLUDED.merchant RETURNING merchant`,
          [fields.get('id'), session]);
        if (!saved.rows.length) return response(409, page('Associação não concluída',
          '<p>A autorização expirou ou esta central já está vinculada a outra loja de teste.</p>'));
        return response(303, '', { Location: ROOT });
      }
      if (req.method === 'POST' && action === 'catalog') {
        const connection = await access();
        if (!connection) return response(409);
        const catalog = await read('/catalog', connection);
        if (!Array.isArray(catalog?.categories)) throw new Error('Catálogo inválido');
        const published = catalog.categories.map(category => ({ name: category.name,
          items: (Array.isArray(category.items) ? category.items : []).map(item => ({ name: item.name, price: item.price })) }));
        await query('UPDATE sandbox_store SET catalog=$1 WHERE merchant=$2', [JSON.stringify(published), connection.row.merchant]);
        return response(303, '', { Location: ROOT });
      }
      if (req.method === 'POST' && action === 'orders') {
        return await syncOrders() ? response(303, '', { Location: ROOT }) : response(409);
      }
      return response(404);
    } catch (error) {
      if (url.pathname === '/webhooks/cardapio-web') return response(503);
      return response(error.status === 429 ? 429 : 503, page('Consulta indisponível',
        '<p>Confira a configuração do Sandbox ou tente novamente mais tarde.</p>'));
    }
  }
  return { handle, runScheduled };
}
