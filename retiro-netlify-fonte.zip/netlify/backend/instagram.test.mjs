import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import { instagramSettings, receiveInstagram } from './instagram.mjs';

export async function verifyInstagramFixtures() {
  const settings = instagramSettings({ META_APP_SECRET: 'secret-test', META_VERIFY_TOKEN: 'verify-test',
    INSTAGRAM_ACCOUNT_ID: '123', INSTAGRAM_USERNAME: '@retiro' });
  const inbox = new Map();
  let unavailable = false;
  const query = async (sql, args) => {
    if (unavailable) throw new Error('Simulated database error');
    if (sql.startsWith('INSERT')) {
      for (const event of JSON.parse(args[1])) inbox.set(args[0] + '/' + event.kind + '/' + event.event_id, event);
    }
  };
  const url = 'https://preview.test/webhooks/meta';
  const verify = new Request(url + '?hub.mode=subscribe&hub.challenge=290&hub.verify_token=verify-test');
  assert.equal(await (await receiveInstagram(verify, settings, query)).text(), '290');
  assert.equal((await receiveInstagram(new Request(url + '?hub.mode=subscribe&hub.challenge=290'),
    settings, query)).status, 403);
  const event = { sender: { id: '456' }, recipient: { id: '123' }, message: { mid: 'm1', text: 'Oi' } };
  const comment = { field: 'comments', value: { id: 'c1', from: { id: '789', username: 'teste' }, text: 'Qual o horário?' } };
  const payload = { object: 'instagram', entry: [
    { id: '999', messaging: [event] },
    { id: '123', messaging: [event, { ...event, message: { mid: 'echo', is_echo: true } }], changes: [
      comment, { ...comment, value: { id: 'self', from: { id: '101', username: 'Retiro' }, text: 'Resposta' } },
    ] },
  ] };
  const body = JSON.stringify(payload);
  const signature = 'sha256=' + createHmac('sha256', settings.secret).update(body).digest('hex');
  const notification = signature => new Request(url, { method: 'POST', body,
    headers: { 'X-Hub-Signature-256': signature } });
  assert.equal((await receiveInstagram(notification('sha256=' + '0'.repeat(64)), settings, query)).status, 403);
  assert.equal(inbox.size, 0);
  assert.equal((await receiveInstagram(notification(signature), settings, query)).status, 200);
  assert.equal((await receiveInstagram(notification(signature), settings, query)).status, 200);
  assert.equal(inbox.size, 2);
  assert.equal(inbox.get('123/direct/m1').text_content, 'Oi');
  assert.equal(inbox.get('123/comment/c1').text_content, 'Qual o horário?');
  unavailable = true;
  assert.equal((await receiveInstagram(notification(signature), settings, query)).status, 503);
  assert.equal((await receiveInstagram(verify, settings, query)).status, 503);
}

if (globalThis.process) await verifyInstagramFixtures();
