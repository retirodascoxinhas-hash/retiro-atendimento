import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { sandbox, sandboxConfig } from './cardapio.mjs';

export async function verifyNetlifyFixtures() {
  const origin = 'https://preview.test';
  const code = 'a'.repeat(43);
  const config = sandboxConfig({
    CW_ENVIRONMENT: 'sandbox', CW_CLIENT_ID: 'app-test', CW_WEBHOOK_TOKEN: 'webhook-test',
    CW_REDIRECT_URI: origin + '/cardapio-web/callback', CW_ENCRYPTION_KEY: 'ef'.repeat(32),
    CW_OPERATOR_CODE_SHA256: createHash('sha256').update(code).digest('hex'),
  });
  assert.equal(sandboxConfig({ CW_ENVIRONMENT: 'production' }), null);
  let operator;
  let attempt;
  let challenge;
  let store;
  let broken = false;
  const inbox = new Set();
  const rows = rows => ({ rows });
  const pool = {
    async query(sql, args = []) {
      if (sql.startsWith('INSERT INTO sandbox_operator')) {
        if (operator) return rows([]);
        operator = args[1];
        return rows([{ key_hash: args[0] }]);
      }
      if (sql.includes('SELECT 1 FROM sandbox_operator')) return rows(args[0] === operator ? [1] : []);
      if (sql.startsWith('DELETE FROM sandbox_attempt WHERE expires_at')) return rows([]);
      if (sql.startsWith('INSERT INTO sandbox_attempt (state_hash')) {
        attempt = { hash: args[0], session: args[1], verifier: args[2] };
        return rows([]);
      }
      if (sql.startsWith('DELETE FROM sandbox_attempt WHERE state_hash')) {
        if (attempt?.hash !== args[0] || attempt?.session !== args[1] || !attempt.verifier) return rows([]);
        const consumed = attempt;
        attempt = null;
        return rows([consumed]);
      }
      if (sql.startsWith('INSERT INTO sandbox_attempt VALUES')) {
        attempt = { hash: args[0], session: args[1], merchant: args[2], name: args[3], credentials: args[4] };
        return rows([]);
      }
      if (sql.startsWith('WITH candidate AS')) {
        if (attempt?.hash !== args[0] || attempt?.session !== args[1] || !attempt.merchant) return rows([]);
        store = { merchant: attempt.merchant, name: attempt.name, credentials: attempt.credentials };
        attempt = null;
        return rows([{ merchant: store.merchant }]);
      }
      if (sql.startsWith('WITH store AS')) {
        if (broken) throw new Error('Banco simulado indisponível');
        if (store?.merchant !== args[1]) return rows([]);
        inbox.add(args[0]);
        return rows([{ merchant: args[1] }]);
      }
      throw new Error('Consulta inesperada no teste');
    },
  };
  const app = sandbox(pool, config, async (url, options) => {
    assert.equal(new URL(url).hostname, 'integracao.sandbox.cardapioweb.com');
    if (url.endsWith('/oauth/token')) {
      const verifier = options.body.get('code_verifier');
      assert.equal(createHash('sha256').update(verifier).digest('base64url'), challenge);
      assert.equal(options.body.get('redirect_uri'), config.redirect);
      return Response.json({ token_type: 'Bearer', access_token: 'fake-private', refresh_token: 'fake-refresh', expires_in: 7200 });
    }
    if (url.endsWith('/merchant')) {
      assert.equal(options.headers.Authorization, 'Bearer fake-private');
      return Response.json({ id: 4480, name: 'Loja fictícia' });
    }
    throw new Error('Rota inesperada no teste');
  });
  const get = (path, cookie = '') => app.handle(new Request(origin + path, { headers: { Cookie: cookie } }));
  const post = (path, body, cookie = '', requestOrigin = origin) => app.handle(new Request(origin + path, {
    method: 'POST', headers: { Origin: requestOrigin, Cookie: cookie }, body: new URLSearchParams(body),
  }));
  assert.equal((await get('/cardapio-web')).status, 401);
  assert.equal((await post('/cardapio-web/login', { code }, '', 'https://wrong.test')).status, 403);
  const login = await post('/cardapio-web/login', { code });
  assert.equal(login.status, 303);
  assert.equal((await post('/cardapio-web/login', { code })).status, 403);
  assert.match(login.headers.get('set-cookie'), /Secure; HttpOnly; SameSite=Lax/);
  const cookie = login.headers.get('set-cookie').split(';')[0];
  const start = await post('/cardapio-web/connect', {}, cookie);
  const authorize = new URL((await start.text()).match(/href="(https:\/\/portal[^"]+)"/)[1].replaceAll('&amp;', '&'));
  challenge = authorize.searchParams.get('code_challenge');
  assert.ok(challenge);
  assert.equal(authorize.searchParams.get('code_challenge_method'), 'S256');
  const callback = '/cardapio-web/callback?code=fixture&state=' + authorize.searchParams.get('state');
  assert.equal((await get(callback)).status, 401);
  assert.equal((await get(callback, cookie)).status, 303);
  assert.equal((await get(callback, cookie)).status, 400);
  assert.equal(store, undefined);
  assert.equal((await post('/cardapio-web/confirm', { id: attempt.hash }, cookie)).status, 303);
  assert.equal(store.name, 'Loja fictícia');
  assert.ok(!store.credentials.includes('fake-private'));
  const webhook = (webhookToken, merchant = 4480, id = 'event-1') =>
    app.handle(new Request(origin + '/webhooks/cardapio-web', {
      method: 'POST', headers: { 'X-Webhook-Token': webhookToken },
      body: JSON.stringify({ event_id: id, event_type: 'ORDER_CREATED', merchant_id: merchant, order_id: 9001 }),
    }));
  assert.equal((await webhook('invalid')).status, 403);
  assert.equal((await webhook(config.webhook, 1)).status, 404);
  assert.equal((await webhook(config.webhook)).status, 200);
  assert.equal((await webhook(config.webhook)).status, 200);
  assert.equal(inbox.size, 1);
  broken = true;
  assert.equal((await webhook(config.webhook, 4480, 'event-2')).status, 503);
}

if (globalThis.process) await verifyNetlifyFixtures();
