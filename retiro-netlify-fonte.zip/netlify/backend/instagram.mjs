import { createHash, createHmac, timingSafeEqual } from 'node:crypto';

const MAX_BYTES = 1024 * 1024;
const digest = value => createHash('sha256').update(value).digest();
const list = value => Array.isArray(value) ? value : [];
const id = value => typeof value === 'string' && value.length <= 512 && value.trim() ? value : null;
const reply = (code, text = '') => new Response(text, {
  status: code, headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' },
});

export function instagramSettings(env) {
  const { META_APP_SECRET, META_VERIFY_TOKEN, INSTAGRAM_ACCOUNT_ID, INSTAGRAM_USERNAME } = env;
  const username = INSTAGRAM_USERNAME?.replace(/^@/, '');
  if (!META_APP_SECRET || !META_VERIFY_TOKEN || !/^\d{1,32}$/.test(INSTAGRAM_ACCOUNT_ID ?? '') ||
      !/^[a-z0-9._]{1,30}$/i.test(username ?? '')) return null;
  return { secret: META_APP_SECRET, verify: META_VERIFY_TOKEN, account: INSTAGRAM_ACCOUNT_ID,
    username: username.toLowerCase() };
}

function events(payload, settings) {
  if (payload?.object !== 'instagram') return [];
  const result = [];
  for (const entry of list(payload.entry)) {
    if (entry?.id !== settings.account) continue;
    for (const event of list(entry.messaging)) {
      const message = event?.message;
      const sender = id(event?.sender?.id);
      const messageId = id(message?.mid);
      if (!sender || !messageId || sender === settings.account || event.recipient?.id !== settings.account ||
          message.is_echo || message.is_self) continue;
      result.push({ kind: 'direct', event_id: messageId, sender_id: sender,
        text_content: typeof message.text === 'string' ? message.text.slice(0, 8000) : '' });
    }
    for (const change of list(entry.changes)) {
      const value = change?.value;
      const sender = id(value?.from?.id);
      const username = value?.from?.username ?? value?.username;
      const commentId = id(value?.id);
      if (change?.field !== 'comments' || !sender || !commentId || typeof username !== 'string' ||
          username.toLowerCase() === settings.username || sender === settings.account || typeof value.text !== 'string') continue;
      result.push({ kind: 'comment', event_id: commentId, sender_id: sender,
        text_content: value.text.slice(0, 8000) });
    }
  }
  return result;
}

async function readBody(req) {
  const reader = req.body?.getReader();
  if (!reader) return Buffer.alloc(0);
  const chunks = [];
  let size = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) return Buffer.concat(chunks);
      size += value.byteLength;
      if (size > MAX_BYTES) {
        await reader.cancel();
        return null;
      }
      chunks.push(Buffer.from(value));
    }
  } finally { reader.releaseLock(); }
}

export async function receiveInstagram(req, settings, query) {
  if (!settings) return reply(503, 'Instagram ainda não configurado.');
  if (req.method === 'GET') {
    const params = new URL(req.url).searchParams;
    const provided = params.get('hub.verify_token') ?? '';
    const challenge = params.get('hub.challenge') ?? '';
    if (params.get('hub.mode') !== 'subscribe' || !/^\d{1,32}$/.test(challenge) ||
        !timingSafeEqual(digest(provided), digest(settings.verify))) return reply(403);
    try {
      await query('SELECT 1 FROM instagram_inbox LIMIT 0');
      return reply(200, challenge);
    } catch { return reply(503); }
  }
  if (req.method !== 'POST') return reply(405);
  const signature = req.headers.get('X-Hub-Signature-256') ?? '';
  if (!/^sha256=[a-f0-9]{64}$/.test(signature)) return reply(403);
  let body;
  try { body = await readBody(req); } catch { return reply(400); }
  if (!body) return reply(413);
  const expected = createHmac('sha256', settings.secret).update(body).digest();
  if (!timingSafeEqual(expected, Buffer.from(signature.slice(7), 'hex'))) return reply(403);
  let payload;
  try { payload = JSON.parse(body.toString('utf8')); } catch { return reply(400); }
  const batch = events(payload, settings);
  if (batch.length === 0) return reply(200);
  try {
    await query(`INSERT INTO instagram_inbox (account_id,kind,event_id,sender_id,text_content)
      SELECT $1,kind,event_id,sender_id,text_content FROM jsonb_to_recordset($2::jsonb)
      AS event(kind text,event_id text,sender_id text,text_content text)
      ON CONFLICT (account_id,kind,event_id) DO NOTHING`, [settings.account, JSON.stringify(batch)]);
    return reply(200);
  } catch { return reply(503); }
}
