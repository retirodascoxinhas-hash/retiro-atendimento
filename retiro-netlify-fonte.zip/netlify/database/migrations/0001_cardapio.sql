CREATE TABLE IF NOT EXISTS sandbox_operator (
  key_hash text PRIMARY KEY,
  session_hash text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL
);

CREATE TABLE IF NOT EXISTS sandbox_attempt (
  state_hash text PRIMARY KEY,
  session_hash text NOT NULL,
  verifier text NOT NULL,
  expires_at timestamptz NOT NULL,
  merchant text,
  store_name text,
  credentials text
);

CREATE TABLE IF NOT EXISTS sandbox_store (
  singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton),
  merchant text NOT NULL,
  store_name text NOT NULL,
  credentials text NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  catalog jsonb,
  reconciled_at timestamptz,
  blocked_until timestamptz
);

CREATE TABLE IF NOT EXISTS sandbox_order (
  merchant text NOT NULL,
  remote_id text NOT NULL,
  updated_at timestamptz NOT NULL,
  display_id text,
  status text NOT NULL,
  total numeric,
  PRIMARY KEY (merchant, remote_id)
);

CREATE TABLE IF NOT EXISTS sandbox_event (
  event_id text PRIMARY KEY,
  merchant text NOT NULL,
  order_id text NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  attempts integer NOT NULL DEFAULT 0,
  retry_at timestamptz NOT NULL DEFAULT now(),
  done boolean NOT NULL DEFAULT false
);

CREATE INDEX IF NOT EXISTS sandbox_event_pending ON sandbox_event (retry_at) WHERE NOT done;
CREATE INDEX IF NOT EXISTS sandbox_order_recent ON sandbox_order (merchant, updated_at DESC);
