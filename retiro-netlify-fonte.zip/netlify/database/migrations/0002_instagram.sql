CREATE TABLE IF NOT EXISTS instagram_inbox (
  account_id text NOT NULL,
  kind text NOT NULL CHECK (kind IN ('direct', 'comment')),
  event_id text NOT NULL,
  sender_id text NOT NULL,
  text_content text NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (account_id, kind, event_id)
);

CREATE INDEX IF NOT EXISTS instagram_inbox_received ON instagram_inbox (received_at);
