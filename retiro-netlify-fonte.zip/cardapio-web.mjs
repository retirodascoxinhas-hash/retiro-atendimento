import { createCipheriv, createDecipheriv, createHash, randomBytes, timingSafeEqual } from 'node:crypto';
import { readFileSync } from 'node:fs';

const MINUTE = 60_000;
const HOUR = 60 * MINUTE;
const ROOT = '/cardapio-web';
const PREFIX = '/api/partner/v1';
const random = () => randomBytes(32).toString('base64url');
const hash = value => createHash('sha256').update(value).digest('base64url');
const remoteId = value => {
  if (typeof value === 'number' && !Number.isSafeInteger(value)) throw new Error('ID fora da precisão segura');
  if (typeof value !== 'number' && typeof value !== 'string') throw new Error('ID ausente');
  const id = String(value);
  if (!/^[\w-]{1,128}$/.test(id)) throw new Error('ID remoto inválido');
  return id;
};

export function migrateCW(db) {
  db.exec(readFileSync(new URL('./cw-migration.sql', import.meta.url), 'utf8'));
}

function transaction(db, run) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = run();
    db.exec('COMMIT');
    return result;
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
}

class RemoteError extends Error {
  constructor(status, code, retryAfter) {
    super('Cardápio Web HTTP ' + status);
    this.status = status;
    this.code = code;
    this.retryAfter = retryAfter;
  }
}

export function configCW(env) {
  if (!env.CW_ENVIRONMENT) return null;
  if (env.CW_ENVIRONMENT !== 'sandbox') throw new Error('A liberação atual do Cardápio Web é Sandbox.');
  const redirect = new URL(env.CW_REDIRECT_URI);
  if (redirect.protocol !== 'https:' || redirect.pathname !== ROOT + '/callback' ||
      redirect.search || redirect.hash || redirect.username || redirect.password) {
    throw new Error('Informe o callback HTTPS em /cardapio-web/callback.');
  }
  if (!env.CW_CLIENT_ID || !env.CW_WEBHOOK_TOKEN || !/^[a-f\d]{64}$/i.test(env.CW_ENCRYPTION_KEY ?? '')) {
    throw new Error('Preencha a configuração privada do Cardápio Web.');
  }
  const units = (env.CW_UNITS || 'retiro').split(',').map(unit => unit.trim());
  if (units.some(unit => !/^[\w-]{1,50}$/.test(unit)) || new Set(units).size !== units.length) {
    throw new Error('CW_UNITS deve conter identificadores únicos.');
  }
  if (env.CW_SITES_READ_TOKEN && !/^[\w-]{43,128}$/.test(env.CW_SITES_READ_TOKEN)) {
    throw new Error('CW_SITES_READ_TOKEN deve ser um segredo aleatório em base64url.');
  }
  return {
    environment: 'sandbox', origin: redirect.origin, redirect: env.CW_REDIRECT_URI,
    client: env.CW_CLIENT_ID, webhookToken: env.CW_WEBHOOK_TOKEN,
    key: Buffer.from(env.CW_ENCRYPTION_KEY, 'hex'), units, sitesToken: env.CW_SITES_READ_TOKEN,
  };
}

export function createCW(db, config, transport = fetch) {
  migrateCW(db);
  const { environment, origin, client, key, units } = config;
  const api = 'https://integracao.sandbox.cardapioweb.com';
  const locals = new Map();
  const quotas = new Map();
  const cooldowns = new Map();
  let nextPoll = 0;
  let working = false;
  const get = (sql, ...args) => db.prepare(sql).get(...args);
  const all = (sql, ...args) => db.prepare(sql).all(...args);
  const run = (sql, ...args) => db.prepare(sql).run(...args);
  const slot = (unit, merchant) => [environment, unit, merchant].join('/');
  const installation = unit => get('SELECT * FROM cw_installations WHERE environment=? AND unit=?', environment, unit);

  function encrypt(value, context) {
    const iv = randomBytes(12);
    const cipher = createCipheriv('aes-256-gcm', key, iv);
    cipher.setAAD(Buffer.from(context));
    const body = Buffer.concat([cipher.update(JSON.stringify(value)), cipher.final()]);
    return Buffer.concat([iv, cipher.getAuthTag(), body]).toString('base64url');
  }
  function decrypt(value, context) {
    const data = Buffer.from(value, 'base64url');
    const cipher = createDecipheriv('aes-256-gcm', key, data.subarray(0, 12));
    cipher.setAAD(Buffer.from(context));
    cipher.setAuthTag(data.subarray(12, 28));
    return JSON.parse(Buffer.concat([cipher.update(data.subarray(28)), cipher.final()]));
  }

  async function request(path, { form, token, merchant } = {}) {
    if (merchant) {
      const now = Date.now();
      const cooldown = cooldowns.get(merchant) ?? 0;
      if (now < cooldown) throw new RemoteError(429, 'cooldown', cooldown);
      const limited = /^\/(catalog|merchant)(\?|$)|^\/orders\/(history|summary)/.test(path.slice(PREFIX.length));
      const resource = path.startsWith(PREFIX + '/catalog/');
      const group = limited ? path.split('?')[0] : (resource ? 'catalog-resource' : 'general');
      const id = merchant + '/' + group;
      let quota = quotas.get(id);
      if (!quota || quota.end <= now) {
        quota = { end: now + (limited ? MINUTE : 3 * MINUTE), count: 0 };
        quotas.set(id, quota);
      }
      if (++quota.count > (limited ? 5 : resource ? 100 : 300)) {
        throw new RemoteError(429, 'local_quota', quota.end);
      }
    }
    const response = await transport(api + path, {
      method: form ? 'POST' : 'GET', headers: token ? { Authorization: 'Bearer ' + token } : {},
      body: form && new URLSearchParams(form), signal: AbortSignal.timeout(8000), redirect: 'error',
    });
    if (!response.ok) {
      const data = await response.json().catch(() => null);
      const header = response.headers.get('retry-after');
      const retryAfter = header == null ? 0 : /^\d+$/.test(header)
        ? Date.now() + Number(header) * 1000 : Date.parse(header) || 0;
      if (merchant && response.status === 429) {
        cooldowns.set(merchant, Math.max(retryAfter, Date.now() + MINUTE + Math.floor(Math.random() * 1000)));
      }
      throw new RemoteError(response.status, data?.error, retryAfter);
    }
    if (response.status === 204) return null;
    return response.json();
  }

  async function exchange(form, previous) {
    const data = await request('/api/partner/oauth/token', { form: { ...form, client_id: client } });
    if (typeof data.access_token !== 'string' || !data.access_token ||
        !Number.isFinite(Number(data.expires_in)) || Number(data.expires_in) <= 0 ||
        String(data.token_type).toLowerCase() !== 'bearer') throw new Error('Resposta OAuth incompleta');
    const refresh = data.refresh_token ?? previous?.refresh;
    if (typeof refresh !== 'string' || !refresh) throw new Error('Refresh token ausente');
    return { access: data.access_token, refresh, expiry: Date.now() + Number(data.expires_in) * 1000,
      scope: data.scope ?? previous?.scope ?? '' };
  }

  function grant() {
    const code = random();
    run('INSERT INTO cw_sessions VALUES (?,?,?)', hash(code), 'grant', Date.now() + 5 * MINUTE);
    return code;
  }
  function useGrant(code) {
    const codeHash = hash(code);
    return transaction(db, () => {
      const grant = run("DELETE FROM cw_sessions WHERE hash=? AND kind='grant' AND expires>?", codeHash, Date.now());
      if (!grant.changes) return null;
      const cookie = random();
      run('INSERT INTO cw_sessions VALUES (?,?,?)', hash(cookie), 'operator', Date.now() + 8 * HOUR);
      return cookie;
    });
  }
  function start(session, unit) {
    if (!units.includes(unit)) throw new Error('Unidade inválida');
    const state = random();
    const verifier = randomBytes(48).toString('base64url');
    run('INSERT INTO cw_attempts VALUES (?,?,?,?,?,?)',
      hash(state), session, unit, environment, encrypt(verifier, hash(state)), Date.now() + 10 * MINUTE);
    const target = new URL('https://portal.sandbox.cardapioweb.com/cw-apps');
    target.search = new URLSearchParams({
      client_id: client, redirect_uri: config.redirect, state,
      code_challenge: hash(verifier), code_challenge_method: 'S256',
    });
    return target.href;
  }
  async function callback(session, state, code) {
    const attempt = get(`
      DELETE FROM cw_attempts WHERE state=? AND session=? AND environment=? AND expires>? RETURNING *
    `, hash(state), session, environment, Date.now());
    if (!attempt || !code) throw new Error('Autorização inválida ou expirada');
    const credentials = await exchange({
      grant_type: 'authorization_code', code, redirect_uri: config.redirect,
      code_verifier: decrypt(attempt.verifier, attempt.state),
    });
    const store = await request(PREFIX + '/merchant', { token: credentials.access });
    const merchant = remoteId(store.id);
    const name = store.name;
    if (typeof name !== 'string' || !name.trim()) throw new Error('Identidade da loja incompleta');
    const id = random();
    run('INSERT INTO cw_candidates VALUES (?,?,?,?,?,?,?,?)', id, session, attempt.unit, environment,
      merchant, name, encrypt(credentials, slot(attempt.unit, merchant)), Date.now() + 10 * MINUTE);
    return { id, unit: attempt.unit, merchant, name };
  }
  function confirm(session, id) {
    return transaction(db, () => {
      const pending = get('SELECT * FROM cw_candidates WHERE id=? AND session=? AND environment=? AND expires>?',
        id, session, environment, Date.now());
      if (!pending || !units.includes(pending.unit)) throw new Error('Confirmação expirada');
      const existing = installation(pending.unit);
      if (existing && existing.merchant !== pending.merchant) {
        throw new Error('A unidade já está vinculada a outro identificador. Cadastre uma unidade distinta.');
      }
      const other = get('SELECT unit FROM cw_installations WHERE environment=? AND merchant=?', environment, pending.merchant);
      if (other && other.unit !== pending.unit) throw new Error('Esta loja já está vinculada a outra unidade.');
      if (locals.has(pending.unit) || installation(pending.unit)?.status === 'revoking') {
        throw new Error('Aguarde o término da operação em andamento.');
      }
      run(`
        INSERT INTO cw_installations (unit,environment,merchant,name,credentials,status,last_read)
        VALUES (?,?,?,?,?,'active',?) ON CONFLICT(environment,unit) DO UPDATE SET
        name=excluded.name,credentials=excluded.credentials,status='active',last_read=excluded.last_read,error=NULL
      `, pending.unit, environment, pending.merchant, pending.name, pending.credentials, Date.now());
      run('DELETE FROM cw_candidates WHERE id=?', id);
    });
  }

  function alone(unit, work) {
    if (locals.has(unit)) return Promise.reject(new Error('Operação em andamento'));
    const promise = Promise.resolve().then(work).finally(() => locals.delete(unit));
    locals.set(unit, promise);
    return promise;
  }
  async function access(connection) {
    const context = slot(connection.unit, connection.merchant);
    let credentials = decrypt(connection.credentials, context);
    if (Date.now() + MINUTE >= credentials.expiry) {
      credentials = await exchange({ grant_type: 'refresh_token', refresh_token: credentials.refresh }, credentials);
      run('UPDATE cw_installations SET credentials=? WHERE environment=? AND unit=?',
        encrypt(credentials, context), environment, connection.unit);
    }
    return credentials.access;
  }
  async function read(unit, path) {
    const connection = installation(unit);
    if (connection?.status !== 'active') throw new Error('Instalação precisa reconectar');
    try {
      const token = await access(connection);
      const data = await request(path, { token, merchant: connection.merchant });
      run('UPDATE cw_installations SET last_read=?,error=NULL WHERE environment=? AND unit=?',
        Date.now(), environment, unit);
      return data;
    } catch (error) {
      if (error.status === 401 || error.code === 'invalid_grant') {
        run("UPDATE cw_installations SET status='reconnect' WHERE environment=? AND unit=?", environment, unit);
      }
      if (error.status === 403) {
        run("UPDATE cw_installations SET status='permissions' WHERE environment=? AND unit=?", environment, unit);
      }
      const label = error instanceof RemoteError ? error.message : 'Falha de comunicação ou resposta inválida';
      run('UPDATE cw_installations SET error=? WHERE environment=? AND unit=?', label, environment, unit);
      throw error;
    }
  }
  async function disconnect(unit) {
    return alone(unit, async () => {
      const connection = installation(unit);
      if (!connection?.credentials) return;
      run("UPDATE cw_installations SET status='revoking' WHERE environment=? AND unit=?", environment, unit);
      try {
        const credentials = decrypt(connection.credentials, slot(unit, connection.merchant));
        await request('/api/partner/oauth/revoke', { form: { token: credentials.refresh, client_id: client } });
        run("UPDATE cw_installations SET status='disconnected',credentials=NULL,error=NULL WHERE environment=? AND unit=?",
          environment, unit);
      } catch {
        run("UPDATE cw_installations SET status='revocation_pending',error='Revogação não confirmada' WHERE environment=? AND unit=?",
          environment, unit);
        throw new Error('Revogação não confirmada. A sincronização está pausada.');
      }
    });
  }

  function acceptEvent(header, payload) {
    if (typeof header !== 'string' || header.length > 2048 ||
        !timingSafeEqual(Buffer.from(hash(header)), Buffer.from(hash(config.webhookToken)))) return 403;
    if (!['ORDER_CREATED', 'ORDER_STATUS_UPDATED'].includes(payload?.event_type)) return 400;
    let ids;
    try {
      ids = [payload.event_id, payload.merchant_id, payload.order_id].map(remoteId);
    } catch { return 400; }
    const [event, merchant, order] = ids;
    return transaction(db, () => {
      const connected = get("SELECT unit FROM cw_installations WHERE environment=? AND merchant=? AND status='active'",
        environment, merchant);
      if (!connected) return 404;
      const now = Date.now();
      run('INSERT OR IGNORE INTO cw_inbox(environment,event,unit,merchant,order_id,received) VALUES (?,?,?,?,?,?)',
        environment, event, connected.unit, merchant, order, now);
      run('UPDATE cw_installations SET last_event=? WHERE environment=? AND unit=?', now, environment, connected.unit);
      return 200;
    });
  }

  function upsert(connection, order, expected) {
    const id = remoteId(order.id);
    const updated = Date.parse(order.updated_at);
    if (!Number.isFinite(updated) || (expected && id !== expected) ||
        (order.merchant_id != null && remoteId(order.merchant_id) !== connection.merchant)) {
      throw new Error('Pedido inconsistente');
    }
    const privateFields = new Set(['customer', 'delivery_address', 'user', 'observation', 'card_number', 'fiscal_document']);
    const payload = JSON.stringify(order, (field, value) => privateFields.has(field) ? undefined : value);
    run(`
      INSERT INTO cw_orders VALUES (?,?,?,?,?,?)
      ON CONFLICT(environment,unit,merchant,id) DO UPDATE SET updated=excluded.updated,payload=excluded.payload
      WHERE excluded.updated>cw_orders.updated OR
        (excluded.updated=cw_orders.updated AND json_type(cw_orders.payload,'$.items') IS NULL
          AND json_type(excluded.payload,'$.items')='array')
    `, environment, connection.unit, connection.merchant, id, updated, payload);
    return updated;
  }
  function importSummaries(connection, rows) {
    for (const order of rows) {
      const updated = upsert(connection, order);
      if (Array.isArray(order.items)) continue;
      const id = remoteId(order.id);
      const stored = get("SELECT updated,json_type(payload,'$.items') AS details FROM cw_orders WHERE environment=? AND unit=? AND merchant=? AND id=?",
        environment, connection.unit, connection.merchant, id);
      if (stored.updated !== updated || stored.details === 'array') continue;
      run('INSERT OR IGNORE INTO cw_inbox(environment,event,unit,merchant,order_id,received) VALUES (?,?,?,?,?,?)',
        environment, 'detail:' + connection.merchant + ':' + id + ':' + updated,
        connection.unit, connection.merchant, id, Date.now());
    }
  }
  async function poll(unit) {
    return alone(unit, async () => {
      const connection = installation(unit);
      const now = Date.now();
      if (connection?.status !== 'active') throw new Error('Instalação precisa reconectar');
      const since = connection.watermark == null ? now - 8 * HOUR
        : Math.max(now - 24 * HOUR + MINUTE, Math.min(now, connection.watermark) - 2 * MINUTE);
      const data = await read(unit, PREFIX + '/orders?' + new URLSearchParams({ updated_since: new Date(since).toISOString() }));
      const rows = Array.isArray(data) ? data : data?.orders;
      if (!Array.isArray(rows)) throw new Error('Formato inesperado na listagem de pedidos');
      transaction(db, () => {
        importSummaries(connection, rows);
        run('UPDATE cw_installations SET watermark=?,last_poll=? WHERE environment=? AND unit=?',
          now, now, environment, unit);
      });
    });
  }
  async function workOnce() {
    if (working) return;
    working = true;
    try {
      const now = Date.now();
      const job = get(`
        SELECT i.* FROM cw_inbox i JOIN cw_installations s
        ON s.environment=i.environment AND s.unit=i.unit AND s.merchant=i.merchant
        WHERE i.environment=? AND i.status='queued' AND i.available<=? AND s.status='active'
        ORDER BY i.received LIMIT 1
      `, environment, now);
      if (job && units.includes(job.unit) && !locals.has(job.unit)) {
        await alone(job.unit, async () => {
          try {
            const order = await read(job.unit, PREFIX + '/orders/' + encodeURIComponent(job.order_id));
            transaction(db, () => {
              upsert(job, order, job.order_id);
              run("UPDATE cw_inbox SET status='done' WHERE environment=? AND event=?", environment, job.event);
            });
          } catch (error) {
            const available = Math.max(error.retryAfter ?? 0, now + Math.min(2 ** job.retry, 300) * 1000 + Math.random() * 500);
            run('UPDATE cw_inbox SET retry=retry+1,available=?,status=? WHERE environment=? AND event=?',
              Math.ceil(available), job.retry >= 7 || error.status === 403 ? 'failed' : 'queued', environment, job.event);
          }
        });
      }
      if (Date.now() >= nextPoll) {
        nextPoll = Date.now() + 30_000;
        run('DELETE FROM cw_sessions WHERE expires<=?', now);
        run('DELETE FROM cw_attempts WHERE expires<=?', now);
        run('DELETE FROM cw_candidates WHERE expires<=?', now);
        for (const { unit } of all("SELECT unit FROM cw_installations WHERE environment=? AND status='active'", environment)) {
          if (locals.has(unit) || !units.includes(unit)) continue;
          try { await poll(unit); } catch (error) {
            if (error.retryAfter) nextPoll = Math.max(nextPoll, error.retryAfter);
            if (!(error instanceof RemoteError)) {
              run('UPDATE cw_installations SET error=? WHERE environment=? AND unit=?',
                'Reconciliação de pedidos incompleta', environment, unit);
            }
          }
        }
      }
    } finally { working = false; }
  }

  async function refreshCatalog(unit) {
    return alone(unit, async () => {
      const catalog = await read(unit, PREFIX + '/catalog');
      if (!catalog || !Array.isArray(catalog.categories)) throw new Error('Catálogo não reconhecido');
      run('UPDATE cw_installations SET catalog=? WHERE environment=? AND unit=?',
        JSON.stringify(catalog), environment, unit);
    });
  }

  function dates(fields, scheduled, years) {
    const parse = name => {
      const value = fields.get(name) ?? '';
      if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error('Informe o período');
      const date = new Date(value + 'T00:00:00Z');
      if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value) {
        throw new Error('Data inválida');
      }
      return date;
    };
    const start = parse('start_date');
    const end = parse('end_date');
    const oldest = new Date();
    oldest.setUTCFullYear(oldest.getUTCFullYear() - years);
    oldest.setUTCHours(0, 0, 0, 0);
    const maxEnd = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + 6, 1));
    const lastDay = new Date(Date.UTC(maxEnd.getUTCFullYear(), maxEnd.getUTCMonth() + 1, 0)).getUTCDate();
    maxEnd.setUTCDate(Math.min(start.getUTCDate(), lastDay));
    if (start < oldest || end < start || end >= maxEnd) throw new Error('Período fora dos limites');
    return new URLSearchParams({
      start_date: fields.get('start_date') + (scheduled ? '' : 'T00:00:00-03:00'),
      end_date: fields.get('end_date') + (scheduled ? '' : 'T23:59:59.999-03:00'),
    });
  }
  async function history(unit, fields) {
    const query = dates(fields, false, 1);
    const pageNumber = Number(fields.get('page') ?? 1);
    if (!Number.isSafeInteger(pageNumber) || pageNumber < 1) throw new Error('Página inválida');
    query.set('page', pageNumber);
    query.set('per_page', '100');
    return alone(unit, async () => {
      const connection = installation(unit);
      const result = await read(unit, PREFIX + '/orders/history?' + query);
      if (!Array.isArray(result?.orders) || !Number.isInteger(result.pagination?.total_pages)) {
        throw new Error('Histórico não reconhecido');
      }
      transaction(db, () => importSummaries(connection, result.orders));
      return result.pagination;
    });
  }
  async function indicators(unit, fields) {
    const dateField = fields.get('date_field') ?? 'created_at';
    if (!['created_at', 'scheduled_date'].includes(dateField)) throw new Error('Recorte inválido');
    const group = fields.get('group_by') ?? '';
    if (!['', 'day', 'hour'].includes(group) || (group === 'hour' && dateField === 'scheduled_date')) {
      throw new Error('Agrupamento inválido');
    }
    const query = dates(fields, dateField === 'scheduled_date', 3);
    const filters = fields.getAll('status');
    if (filters.some(status => !['closed', 'canceled'].includes(status))) throw new Error('Status inválido');
    for (const status of filters) query.append('filters[status_in]', status);
    query.set('date_field', dateField);
    if (group) query.set('group_by', group);
    return alone(unit, () => read(unit, PREFIX + '/orders/summary' + (group ? '/grouped' : '') + '?' + query));
  }

  const escape = value => String(value ?? '').replace(/[&<>"']/g, ch =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);
  const showDate = time => time ? new Date(time).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' }) : 'Não confirmado';
  const statuses = { active: 'Ativo', disconnected: 'Desconectado', reconnect: 'Precisa reconectar',
    permissions: 'Verificar permissões', revocation_pending: 'Revogação pendente', revoking: 'Desconectando' };
  const orderStatuses = new Map(Object.entries({
    waiting_confirmation: 'Aguardando confirmação', pending_payment: 'Pagamento pendente',
    pending_online_payment: 'Pagamento online pendente', scheduled_confirmed: 'Agendamento confirmado',
    confirmed: 'Em preparação', ready: 'Pronto', released: 'Saiu para entrega',
    waiting_to_catch: 'Aguardando retirada', delivered: 'Entregue', canceling: 'Cancelamento em andamento',
    canceled: 'Cancelado', closed: 'Finalizado',
  }));
  const orderTypes = new Map(Object.entries({ delivery: 'Entrega', takeout: 'Retirada',
    onsite: 'Consumo no local', closed_table: 'Mesa encerrada' }));
  const button = (action, label, unit, extra = '') =>
    '<form method="post" action="' + ROOT + '/' + action + '">' +
    '<input type="hidden" name="unit" value="' + escape(unit) + '">' + extra +
    '<button>' + label + '</button></form>';
  const page = (title, body) => `<!doctype html><html lang="pt-BR"><meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1"><title>${escape(title)}</title>
    <style>
    *{box-sizing:border-box}body{margin:0;background:#f7f7f4;color:#242823;font:1rem system-ui}
    aside{background:#e7ece4;padding:1.4rem}aside a{display:block;padding:.5rem;color:#184836}
    main{padding:1.5rem;max-width:75rem;min-width:0}h1{margin-top:0}
    article{background:white;border:1px solid #d6ddd6;border-radius:.6rem;padding:1rem;margin:1rem 0}
    form{margin:.5rem 0}button,input,select{font:inherit;padding:.5rem;border:1px solid #48745f;border-radius:.25rem}
    button{background:#174e39;color:white;cursor:pointer}a{color:#164d39}
    :focus-visible{outline:3px solid #aa5200;outline-offset:3px}pre{white-space:pre-wrap;overflow-wrap:anywhere}
    summary{cursor:pointer;padding:.5rem}label{display:inline-block;margin:.4rem}
    @media(min-width:740px){body{display:grid;grid-template-columns:15rem minmax(0,1fr);min-height:100vh}}
    </style><aside><details open><summary>Retiro Atendimento</summary>
    <nav><a href="${ROOT}">Conexões</a><a href="${ROOT}/orders">Pedidos</a>
    <a href="${ROOT}/catalog">Cardápio</a><a href="${ROOT}/reports">Indicadores</a>
    <a href="${ROOT}/health">Saúde</a></nav></details></aside>
    <main><h1>${escape(title)}</h1>${body}</main></html>`;

  async function readBody(req, limit) {
    const chunks = [];
    let size = 0;
    for await (const chunk of req) {
      size += chunk.length;
      if (size > limit) throw new Error('Corpo excede o limite');
      chunks.push(chunk);
    }
    return Buffer.concat(chunks).toString('utf8');
  }
  function formRequired(req) {
    return req.headers.origin === origin &&
      req.headers['content-type']?.split(';')[0] === 'application/x-www-form-urlencoded';
  }
  const dateFields = '<label>Data inicial <input type="date" name="start_date" required></label>' +
    '<label>Data final <input type="date" name="end_date" required></label>';
  async function handle(req, res, url) {
    const path = url.pathname;
    if (path !== '/webhooks/cardapio-web' && path !== ROOT && !path.startsWith(ROOT + '/')) return false;
    const reply = (code, body = '', headers = {}) => {
      res.writeHead(code, {
        'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store',
        'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'",
        'Referrer-Policy': 'no-referrer', 'X-Content-Type-Options': 'nosniff', ...headers,
      });
      res.end(body);
      return true;
    };
    if (path === '/webhooks/cardapio-web') {
      if (req.method !== 'POST') return reply(405);
      let payload;
      try { payload = JSON.parse(await readBody(req, 64 * 1024)); } catch { return reply(400); }
      try { return reply(acceptEvent(req.headers['x-webhook-token'], payload)); } catch { return reply(503); }
    }
    if (path === ROOT + '/api/overview') {
      if (!config.sitesToken) return reply(404);
      if (req.method !== 'GET') return reply(405);
      const auth = req.headers.authorization;
      if (typeof auth !== 'string' || auth.length > 160 ||
          !timingSafeEqual(Buffer.from(hash(auth)), Buffer.from(hash('Bearer ' + config.sitesToken)))) {
        return reply(401);
      }
      const unit = url.searchParams.get('unit');
      if (!units.includes(unit)) return reply(404);
      const connection = installation(unit);
      const connected = connection?.status === 'active';
      const data = connected ? {
        store: connection.name,
        lastReconciledAt: connection.last_poll,
        categories: connection.catalog ? JSON.parse(connection.catalog).categories.map(category => ({
          id: category.id, name: category.name,
          items: (Array.isArray(category.items) ? category.items : []).map(item => ({
            id: item.id, name: item.name, price: item.price, status: item.status,
          })),
        })) : [],
        recentOrders: all(`
          SELECT id,updated,json_extract(payload,'$.display_id') AS displayId,
            json_extract(payload,'$.status') AS status
          FROM cw_orders WHERE environment=? AND unit=? AND merchant=? ORDER BY updated DESC LIMIT 30
        `, environment, unit, connection.merchant),
      } : {};
      return reply(200, JSON.stringify({ environment, unit, connected, ...data }),
        { 'Content-Type': 'application/json; charset=utf-8' });
    }
    const cookie = req.headers.cookie?.match(/(?:^|;\s*)__Host-cw=([\w-]{43})(?:;|$)/)?.[1];
    const session = cookie && hash(cookie);
    const signedIn = session && get("SELECT 1 FROM cw_sessions WHERE hash=? AND kind='operator' AND expires>?", session, Date.now());
    try {
      if (req.method === 'POST') {
        if (!formRequired(req)) return reply(403);
        const fields = new URLSearchParams(await readBody(req, 4096));
        if (path === ROOT + '/login') {
          const newCookie = useGrant(fields.get('code') ?? '');
          if (!newCookie) return reply(403, page('Código inválido ou expirado', '<a href="' + ROOT + '">Tentar novamente</a>'));
          return reply(303, '', { Location: ROOT, 'Set-Cookie': '__Host-cw=' + newCookie +
            '; Path=/; Secure; HttpOnly; SameSite=Lax; Max-Age=28800' });
        }
        if (!signedIn) return reply(401);
        const unit = fields.get('unit');
        if (path === ROOT + '/confirm') confirm(session, fields.get('id'));
        else {
          if (!units.includes(unit)) return reply(400);
          if (path === ROOT + '/connect') {
            return reply(200, page('Autorizar no Cardápio Web',
              '<p>Selecione a loja com a conta de Proprietário.</p><a href="' +
              escape(start(session, unit)) + '">Continuar para o Cardápio Web</a>'));
          }
          if (path === ROOT + '/disconnect') await disconnect(unit);
          else if (path === ROOT + '/history') {
            const pagination = await history(unit, fields);
            const nextPage = pagination.current_page + 1;
            return reply(200, page('Histórico importado', '<p>Página ' + escape(pagination.current_page) +
              ' de ' + escape(pagination.total_pages) + '. Os detalhes entram na fila.</p><a href="' +
              ROOT + '/orders?unit=' + encodeURIComponent(unit) + '">Ver pedidos</a>' +
              (nextPage <= pagination.total_pages ? button('history', 'Importar próxima página', unit,
                ['start_date', 'end_date', 'page'].map(key => '<input type="hidden" name="' + key + '" value="' +
                  escape(key === 'page' ? nextPage : fields.get(key)) + '">').join('')) : '')));
          } else if (path === ROOT + '/reports') {
            const report = await indicators(unit, fields);
            return reply(200, page('Indicadores', '<p>' + escape(unit) + ' · ' +
              escape(fields.get('start_date')) + ' a ' + escape(fields.get('end_date')) +
              ' · datas de criação em UTC−03:00. Agrupamentos seguem o fuso da loja.</p>' +
              '<p>Valores totais do provedor. Consulta em ' + escape(showDate(Date.now())) + '.</p><pre>' +
              escape(JSON.stringify(report, null, 2)) + '</pre><a href="' + ROOT + '/reports">Nova consulta</a>'));
          }
          else if (path === ROOT + '/refresh-catalog') {
            await refreshCatalog(unit);
            return reply(303, '', { Location: ROOT + '/catalog?unit=' + encodeURIComponent(unit) });
          } else return reply(404);
        }
        return reply(303, '', { Location: ROOT });
      }
      if (req.method !== 'GET') return reply(405);
      if (!signedIn) return reply(401, page('Acesso do operador',
        '<p>Gere um código de uso único no terminal com <code>node atendimento.mjs cw-login</code>.</p>' +
        button('login', 'Entrar', '', '<label>Código de acesso <input required name="code" autocomplete="off"></label>')));
      if (path === ROOT + '/callback') {
        if (url.searchParams.has('error')) return reply(403, page('Autorização recusada',
          '<p>Entre no Cardápio Web com o perfil Proprietário da loja e inicie uma nova tentativa.</p>' +
          '<a href="' + ROOT + '">Voltar para Conexões</a>'));
        const pending = await callback(session, url.searchParams.get('state') ?? '', url.searchParams.get('code'));
        return reply(200, page('Conferir loja autorizada', '<p>Unidade: ' + escape(pending.unit) +
          '. Loja: ' + escape(pending.name) + ' (' + escape(pending.merchant) + ').</p>' +
          button('confirm', 'Associar esta loja', pending.unit, '<input type="hidden" name="id" value="' +
            escape(pending.id) + '">') + '<a href="' + ROOT + '">Voltar e recomeçar</a>'));
      }
      if (path === ROOT) return reply(200, page('Conexões', '<p>Sandbox · autorização exclusiva do perfil Proprietário.</p>' +
        units.map(unit => {
          const row = installation(unit);
          const scopes = row?.credentials ? decrypt(row.credentials, slot(unit, row.merchant)).scope : '';
          return '<article><h2>' + escape(unit) + '</h2><p>' + escape(statuses[row?.status] ?? 'Aguardando proprietário') +
            '</p><p>' + escape(row?.name) + ' ' + escape(row?.merchant) + '</p><p>Permissões: ' +
            escape(scopes || 'Não confirmadas') + '</p><p>Última leitura: ' + escape(showDate(row?.last_read)) + '</p>' +
            button('connect', row ? 'Reconectar' : 'Autorizar loja', unit) +
            (row?.credentials ? '<details><summary>Desconectar</summary><p>Pausa a sincronização e solicita revogação.</p>' +
              button('disconnect', 'Confirmar desconexão', unit) + '</details>' : '') + '</article>';
        }).join('')));
      if (path === ROOT + '/orders') {
        const selected = url.searchParams.get('unit') || units[0];
        if (!units.includes(selected)) return reply(404);
        const id = url.searchParams.get('id')?.trim();
        const status = url.searchParams.get('status')?.trim();
        const type = url.searchParams.get('type')?.trim();
        const channel = url.searchParams.get('channel')?.trim();
        const startDate = url.searchParams.get('start_date')?.trim();
        const endDate = url.searchParams.get('end_date')?.trim();
        if ([startDate, endDate].some(date => date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) ||
            (startDate && endDate && startDate > endDate)) return reply(400, page('Período inválido', 'Revise as datas.'));
        const filters = [
          [id, 'id=?'],
          [status, "json_extract(payload,'$.status')=?"],
          [type, "json_extract(payload,'$.order_type')=?"],
          [channel, "json_extract(payload,'$.sales_channel')=?"],
          [startDate, "substr(json_extract(payload,'$.created_at'),1,10)>=?"],
          [endDate, "substr(json_extract(payload,'$.created_at'),1,10)<=?"],
        ].filter(([value]) => value);
        const row = installation(selected);
        const sql = 'SELECT id,payload FROM cw_orders WHERE environment=? AND unit=? AND merchant=?';
        const orders = row ? all(sql + filters.map(([, condition]) => ' AND ' + condition).join('') +
          ' ORDER BY updated DESC LIMIT 100', environment, selected, row.merchant, ...filters.map(([value]) => value)) : [];
        const select = (name, choices, selected) => '<select name="' + name + '"><option value="">Todos</option>' +
          [...choices].map(([key, label]) => '<option value="' + escape(key) + '"' +
            (key === selected ? ' selected' : '') + '>' + escape(label) + '</option>').join('') + '</select>';
        return reply(200, page('Pedidos', '<form><label>Unidade <select name="unit">' +
          units.map(unit => '<option' + (unit === selected ? ' selected' : '') + '>' + escape(unit) + '</option>').join('') +
          '</select></label><label>ID do pedido <input name="id" value="' + escape(id) +
          '"></label><label>Status ' + select('status', orderStatuses, status) + '</label><label>Tipo ' +
          select('type', orderTypes, type) + '</label><label>Canal <input name="channel" value="' + escape(channel) +
          '"></label><label>Data inicial <input type="date" name="start_date" value="' + escape(startDate) +
          '"></label><label>Data final <input type="date" name="end_date" value="' + escape(endDate) +
          '"></label><button>Filtrar</button></form>' +
          (row?.status === 'active' ? '<details><summary>Importar histórico</summary>' +
            button('history', 'Importar página', selected, dateFields) + '</details>' : '') +
          (!row?.last_poll ? '<p>Primeira reconciliação ainda não confirmada.</p>' : '') +
          (row?.error ? '<p>' + escape(row.error) + '</p>' : '') + (orders.length ? orders.map(order => {
            const value = JSON.parse(order.payload);
            return '<article><details><summary>Pedido ' + escape(value.display_id ?? order.id) + ' · ' +
              escape(orderStatuses.get(value.status) ?? value.status ?? 'Status desconhecido') + ' · ID ' +
              escape(order.id) + '</summary>' +
              (Array.isArray(value.items) ? '' : '<p>Detalhes aguardando sincronização.</p>') + '<pre>' +
              escape(JSON.stringify(value, null, 2)) + '</pre></details></article>';
          }).join('') : filters.length ? '<p>Nenhum pedido corresponde aos filtros.</p>' : '<p>Nenhum pedido encontrado.</p>')));
      }
      if (path === ROOT + '/catalog') return reply(200, page('Cardápio', units.map(unit => {
        const row = installation(unit);
        const menu = row?.catalog && JSON.parse(row.catalog);
        return '<article><h2>' + escape(unit) + '</h2>' + (row?.status === 'active'
          ? button('refresh-catalog', 'Consultar catálogo', unit) : '<p>Conecte a unidade para consultar.</p>') +
          (menu ? menu.categories.map(category => '<details><summary>' + escape(category.name) +
            '</summary><pre>' + escape(JSON.stringify(category, null, 2)) + '</pre></details>').join('') :
            '<p>Sem catálogo carregado.</p>') + '</article>';
      }).join('')));
      if (path === ROOT + '/reports') return reply(200, page('Indicadores', units.map(unit =>
        '<article><h2>' + escape(unit) + '</h2>' + (installation(unit)?.status === 'active'
          ? button('reports', 'Consultar indicadores', unit, dateFields +
            '<label>Data de referência <select name="date_field"><option value="created_at">Criação</option>' +
            '<option value="scheduled_date">Agendamento</option></select></label>' +
            '<label>Agrupar por <select name="group_by"><option value="">Nenhum</option><option value="day">Dia</option>' +
            '<option value="hour">Hora</option></select></label>' +
            '<label><input type="checkbox" name="status" value="closed"> Finalizados</label>' +
            '<label><input type="checkbox" name="status" value="canceled"> Cancelados</label>')
          : '<p>Conecte a unidade para consultar.</p>') + '</article>').join('')));
      if (path === ROOT + '/health') return reply(200, page('Saúde da integração', units.map(unit => {
        const row = installation(unit);
        const jobs = all('SELECT status,count(*) AS n FROM cw_inbox WHERE environment=? AND unit=? GROUP BY status', environment, unit);
        return '<article><h2>' + escape(unit) + '</h2><p>Webhook: ' + showDate(row?.last_event) +
          '</p><p>Última leitura: ' + showDate(row?.last_read) + '</p><p>Reconciliação: ' + showDate(row?.last_poll) +
          '</p><p>Fila: ' + escape(jobs.map(job => job.status + ' ' + job.n).join(', ') || 'Vazia') +
          '</p><p>' + escape(row?.error) + '</p></article>';
      }).join('')));
      return reply(404);
    } catch (error) {
      const safe = error instanceof RemoteError ? error.message : 'Verifique o acesso da unidade e tente novamente.';
      return reply(400, page('Operação não concluída', '<p>' + escape(safe) + '</p><a href="' + ROOT + '">Voltar</a>'));
    }
  }
  return { handle, grant, useGrant, start, callback, confirm, disconnect, acceptEvent, workOnce, poll, refreshCatalog,
    history, indicators };
}
