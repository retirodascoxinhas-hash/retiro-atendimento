CREATE TABLE IF NOT EXISTS cw_sessions (
  hash TEXT PRIMARY KEY, kind TEXT NOT NULL, expires INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS cw_attempts (
  state TEXT PRIMARY KEY, session TEXT NOT NULL, unit TEXT NOT NULL,
  environment TEXT NOT NULL, verifier TEXT NOT NULL, expires INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS cw_candidates (
  id TEXT PRIMARY KEY, session TEXT NOT NULL, unit TEXT NOT NULL,
  environment TEXT NOT NULL, merchant TEXT NOT NULL, name TEXT NOT NULL,
  credentials TEXT NOT NULL, expires INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS cw_installations (
  unit TEXT NOT NULL, environment TEXT NOT NULL, merchant TEXT NOT NULL, name TEXT NOT NULL,
  credentials TEXT, status TEXT NOT NULL, last_read INTEGER, last_poll INTEGER,
  last_event INTEGER, watermark INTEGER, error TEXT, catalog TEXT,
  PRIMARY KEY (environment, unit), UNIQUE (environment, merchant)
);
CREATE TABLE IF NOT EXISTS cw_orders (
  environment TEXT NOT NULL, unit TEXT NOT NULL, merchant TEXT NOT NULL,
  id TEXT NOT NULL, updated INTEGER NOT NULL, payload TEXT NOT NULL,
  PRIMARY KEY (environment, unit, merchant, id)
);
CREATE TABLE IF NOT EXISTS cw_inbox (
  environment TEXT NOT NULL, event TEXT NOT NULL, unit TEXT NOT NULL,
  merchant TEXT NOT NULL, order_id TEXT NOT NULL, received INTEGER NOT NULL,
  retry INTEGER NOT NULL DEFAULT 0, available INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'queued',
  PRIMARY KEY (environment,event)
);
